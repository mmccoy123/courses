<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Courses extends CI_Controller {

	// public function __construct()
	// {
	// 	parent::__construct();

	// 	$this->output->enable_profiler(TRUE);
	// }

	public function index()
	{
		$this->load->model("Course");

		$list_of_courses = $this->Course->get_all_courses();

		$this->load->view('course_list', [ "list_of_courses" => $list_of_courses]);



	}

	public function add()
	{
		var_dump($this->input->post());
		


		$this->load->library("form_validation");
		$this->form_validation->set_rules("course_name", "Course Name", "trim|required");
		if($this->form_validation->run() === FALSE)
		{
     		$this->session->set_userdata('form_errors', validation_errors());
     		redirect("/");

		}

		$data = array(
			'name' => $this->input->post('course_name'),
			'description' => $this->input->post('course_desc')
			);

		$this->load->model("Course");

		$this->Course->add_course($data);
	}


	public function destroy($id)
	{
		$this->load->model("Course");

		$course_to_delete = $this->Course->get_course_by_id($id);

		$this->load->view('confirm_delete', ["course_to_delete" => $course_to_delete]);
	}

	public function confirmed_delete($id)
	{
		$this->load->model("Course");

		$this->Course->delete_course($id);

	}

}
