<?php 

class Course extends CI_Model 
{


	function get_all_courses()
	{
		// Commented section is the non-Active Record method to run these SQL queries
		//return $this->db->query("SELECT * FROM course_list")->result_array();

		
		$this->db->order_by("date_added", "desc");
		$query=$this->db->get('course_list')->result();

		return $query;
	}

	function get_course_by_id($course_id)
	{
		// Commented section is the non-Active Record method to run these SQL queries
		//return $this->db->query("SELECT * FROM course_list WHERE id = ?", array($course_id))->row_array();

		$query = $this->db->get_where('course_list', array('id' => $course_id))->result();

		return $query;
	}


	function add_course($data)
	{
		
		// Commented section is the non-Active Record method to run these SQL queries
		// $query = "INSERT INTO course_list (title, description, created_at) VALUES (?,?,?)";
		// $values = array($course['title'], $course['description'], date("Y-m-d, H:i:s"));
		// return $this->db->query($query, $values);


		var_dump($data);

		echo $data['name'];

		$this->db->set('name', $data['name']);
		$this->db->set('description', $data['description']);
		$this->db->set('date_added', 'NOW()', FALSE);
		$this->db->insert('course_list');

		redirect('/');
	}

	function delete_course($id)
	{

		$this->db->where('id', $id);
		$this->db->delete('course_list');

		redirect("/");


	}


}


 ?>