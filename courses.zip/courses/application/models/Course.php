<?php 

class Course extends CI_Model 
{


	function get_all_courses()
	{
		return $this->db->query("SELECT * FROM course_list")->result_array();
	}

	function get_course_by_id($course_id)
	{
		return $this->db->query("SELECT * FROM course_list WHERE id = ?", array($course_id))->row_array();
	}


	function add_course()
	{
		$query = "INSERT INTO course_list (title, description, created_at) VALUES (?,?,?)";
		$values = array($course['title'], $course['description'], date("Y-m-d, H:i:s"));
		return $this->db->query($query, $values);
	}




}


 ?>