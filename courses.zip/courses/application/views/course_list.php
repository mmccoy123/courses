<html>
<head>
	<title>Course List</title>
	<style type="text/css">

		body {
			font-family: sans-serif;
		}

		textarea {
			vertical-align: top;
		}

		label {
			margin-right: 10px;
		}

		table {
			border: 2px solid  black;
		}

		td {
			padding-left: 10px;
		}

		table td + td { 
			border-left:1px solid black; 
		}

		thead td {
			border-bottom: 2px solid black;
		}

		thead tr {
			background-color: grey;
		}

		a:visited, a:link {
			color: red;
		}

		#container {
			width: 100%;
		}

		#form_div {
			display: inline-block;
			vertical-align: text-top;
			outline: 1px dotted red;
			padding: 20px;
			height: 160px;
			margin-bottom: 20px;
		}

		#course_desc {
			resize: none;
			width: 200px;
			height: 50px;
		}

		#course_name {
			width: 200px;
		}

		.inline-field {
			float: right;
			border: 1px solid black;
		}

		#add_button {
			position: relative;
			bottom: -55px;
			right: -200px;
			background: green;
			color: white;
		}

		#course_list {

		}

		#course_name_column {
			width: 200px;
		}

		#course_desc_column {
			width: 100px;
		}

		#course_date_column {
			width: 100px;
		}

		#course_actions_column {
			width: 80px;
		}

		.even_column {
			background-color: lightgrey;
		}

	</style>
</head>
<body>
	<?php 
		if( null !== $this->session->userdata('form_errors'))
		{
			echo $this->session->userdata('form_errors');
			$this->session->set_userdata('form_errors', '');
		}

	 ?>
	<div id='container'>
		<div id='form_div'>
			<form id='add_course' name='add_course' action='courses/add' method='post'>
				<h3>Add a new course:</h3>
				<label>Name: <input type='text' name='course_name' id='course_name' class='inline-field'></label>
				<br><br>
				<label>Description: <textarea id='course_desc' name='course_desc' class='inline-field'></textarea></label>
				<input type='submit' value='Add' id='add_button'>
			</form>
		</div>
		<div id='course_list'>
			<h3>Courses</h3>
			<table>
				<thead>
					<tr>
						<td id='course_name_column'>Course Name</td>
						<td id='course_desc_column'>Description</td>
						<td id='course_date_column'>Date Added</td>
						<td id='course_actions_column'>Actions</td>
					</tr>
				</thead>
				<?php 
					for ($i = 0; $i < count($list_of_courses); $i++)
					{
						
						if ($i % 2 == 0) {
							echo "<tr class='even_column'>";
						}

						else {
							echo "<tr>";	
						}


						echo "<td>" . $list_of_courses[$i]->name . "</td>";
						echo "<td>" . $list_of_courses[$i]->description . "</td>";
						echo "<td>" . $list_of_courses[$i]->date_added . "</td>";
						echo "<td><a href='courses/destroy/" . $list_of_courses[$i]->id . "''>remove</a></td></tr>";
					}


				 ?>
			</table>
		</div>
	</div>
</body>
</html>
