<html>
<head>
	<title>Confirm Delete</title>
	<style type="text/css">

		body {
			width: 100%;
		}


		#container {
			width: 80%;
			margin: 20px auto;
		}

		#no_button {
			background-color: grey;
			color: black;
			margin-right: 20px;
		}

		#yes_button {
			background-color: red;
			color: white;
			padding: 0px 20px;
		}

	</style>
</head>
<body>
<?php var_dump($course_to_delete); ?>
	<div id='container'>
		<h2>Are you sure you want to delete the following course?</h2>
		<p>Name: <?= $course_to_delete[0]->name;  ?></p>
		<p>Description: <?= $course_to_delete[0]->description;  ?></p>
		<a href="/"><button id="no_button">No</button></a>
		<?= "<a href=/courses/confirmed_delete/" . $course_to_delete[0]->id . "><button id='yes_button'>Yes! I want to delete this</button></a>" ?>
	</div>
</body>
</html>